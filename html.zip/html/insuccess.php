<?php
include 'header.php'
?>
<!DOCTYPE html>
<head>
<title>Submitted Successful</title>
<link rel="stylesheet" type="text/css" href ="succcss.css">
</head>
<body>
<div>
Your registration is successful.Please verify using the provided email to signin.
<div>
</body>