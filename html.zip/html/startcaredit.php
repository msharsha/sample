<?php
session_start();
$_SESSION["edit"]="yes";
?>