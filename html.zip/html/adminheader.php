<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href ="abc.css">
</head>
<body>
<div id="header1">

<ul id="headlist">
<li class="l1"><a href="home.php" class="al1">Home</a></li>
<li class="l1"><a href="cars.php" class="al1">AllCars</a></li>
<li class="l1"><a href="show.php" class="al1">Users</a></li>
<?php include'dropdown.php'?>
</ul>

</div>
</body>
</html>