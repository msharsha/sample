<!DOCTYPE html>
<head>
<title>Home</title>
<link rel="stylesheet" type="text/css" href ="tempcss.css">
</head>

<body>
<?php include 'adminheader.php';?>
<div class="full">
<div class="top1">
<h1 class="carheading">Cars</h1>
</div>
<div class="topleft">
<img src="car1.png" alt="car"  class="image1">
</div>


<div class="rightdiv">
<p id="para">A car is a wheeled, self-powered motor vehicle used for transportation and a product of the automotive industry. Most definitions of the term specify that cars are designed to run primarily on roads, to have seating for one to eight people, to typically have four wheels with tyres, and to be constructed principally for the transport of people rather than goods.</p>
</div>
</div>
<table id="t1">
<tr >
<td class="td2"><a href="" class="al2">model1</a></li></td>
<td class="td2"><a href="" class="al2">model2</a></li></td>
<td class="td2"><a href="" class="al2">model3</a></li></td>
<td class="td2"><a href="" class="al2">model4</a></li></td>
<td class="td2"><a href="" class="al2">model5</a></li></td>
</tr>
<tr >
<td class="td2"><a href="" class="al2">model1</a></li></td>
<td class="td2"><a href="" class="al2">model2</a></li></td>
<td class="td2"><a href="" class="al2">model3</a></li></td>
<td class="td2"><a href="" class="al2">model4</a></li></td>
<td class="td2"><a href="" class="al2">model5</a></li></td>
</tr>
<tr >
<td class="td2"><a href="" class="al2">model1</a></li></td>
<td class="td2"><a href="" class="al2">model2</a></li></td>
<td class="td2"><a href="" class="al2">model3</a></li></td>
<td class="td2"><a href="" class="al2">model4</a></li></td>
<td class="td2"><a href="" class="al2">model5</a></li></td>
</tr>
</table>
<h1 id="fheading">New Arrivals</h1>
<div id="box">
<div class="boxf" style="width:24%;display:inline-block">
<div class="upbox">car1</div>
<div class="imgbox"><img src="car2.jpg" alt="" class="timage"></div>
<div class="downbox">rs 50</div>
</div>
<div class="boxf" style="width:24%;display:inline-block">
<div class="upbox">car2</div>
<div class="imgbox"><img src="car3.jpg" alt="" class="timage"></div>
<div class="downbox">rs 40</div>
</div>
<div class="boxf" style="width:24%;display:inline-block">
<div class="upbox">car3</div>
<div class="imgbox"><img src="car4.jpg" alt="" class="timage"></div>
<div class="downbox">rs 30</div>
</div>
<div class="boxf" style="width:24%;display:inline-block">
<div class="upbox">car4</div>
<div class="imgbox"><img src="car5.jpg" alt="" class="timage"></div>
<div class="downbox">rs 20</div>
</div>
</div>
</div>
</body>
</html>