<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href ="abc.css">
<!--<link rel="stylesheet" type="text/css" href ="dashheader.css">-->
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body>
<div id="header1">

<ul id="headlist">
<li class="l1"><a href="home.php" class="al1">Home</a></li>
<li class="l1"><a href="contact.php" class="al1">Contact</a></li>
<li class="l1"><a href="form.php" class="al1">Signup</a></li>
<li class="l1"><a href="login.php" class="al1">Login</a></li>
</ul>

</div>
</body>
</html>