<link rel="stylesheet" type="text/css" href="footercss.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width,initial-scale=1">
<footer id="footer">
<div class="fleft"><p>STAY CONNECTED</p>
</div>
<div class="fright">
<div class="icon"><i class="fa fa-facebook-f wid2"></i></div>
<div class="icon"><i class="fa fa-twitter wid1" ></i></div>
<div class="icon"><i class="fa fa-instagram wid1" ></i></div>
<div class="icon"><i class="fa fa-google-plus" ></i></div>
</div>
<div class="cop">&copy; Copyrights Cars.Inc
</div>
</footer>
