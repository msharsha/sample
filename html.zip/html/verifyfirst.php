<?php include 'header.php'?>
<!DOCTYPE html>
<head>
<title>Verify</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" type="text/css" href ="verifycss.css">
</head>
<body>
<div class="textclass">
Please verify your email first
</div>

<?php include 'footer.php'?>