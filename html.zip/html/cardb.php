<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname="intern";
$tablename="list1";
$conn = new mysqli($servername, $username, $password, $dbname);
?>